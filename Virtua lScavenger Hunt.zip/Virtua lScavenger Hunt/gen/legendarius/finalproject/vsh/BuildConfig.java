/** Automatically generated file. DO NOT MODIFY */
package legendarius.finalproject.vsh;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}